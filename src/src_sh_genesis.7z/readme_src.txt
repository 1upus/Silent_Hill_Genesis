v2014-11-06

SH: Genesis sources by lupus for Gincs Visual studio
Recomended GVS ver 1.82 or better
Freeware for non commercial use

Project Homepage: https://github.com/1upus/Silent_Hill_Genesis/
GVS homepage: http://emulation.at.ua/news/gincs_visual_studio_1_8_2_hotfix/2013-10-23-23